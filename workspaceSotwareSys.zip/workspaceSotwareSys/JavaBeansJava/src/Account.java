

/**
 * <pre>
 * 		&#64;author 	James O'Neill<br>
 *      Project 	JavaBeansJava
 * 		&#64;version 	1.0<br>
 * 		Date 		11 Mar 2016<br>
 *		UpDated 	11 Mar 2016<br>
 * </pre>
 */
public class Account {
	private String accountID = "";
	private Double balance = 0.0;

	/**
	 * 
	 */
	public Account(String acc, double i) {
		
		//set accountID to acc
		this.accountID = acc;
		//set balance to bal
		this.balance = i;
		
		
	}

	public Double getBalance() {
		
		return balance;
		
	}// end get balance 
	
	
	public String getAccountID() {
		
		return accountID;
		
	}// end get accountID 

	
	
	public void creditAccount(double howMuch) {
		
		//check to see if deposit is positive
		if (howMuch > 0){
			
			balance = balance + howMuch;
			
			System.out.println("your new balance is : �" + balance);
			
		}//end if
		
		else System.out.println("You cannnot enter a negative number!");
		
	}// end credit account method

	public void debitAccount(double howMuch) {
		
		//check to see if debit is positive
		if (howMuch > 0){
		
		//create temporary balance variable wont affect balance yet	until we pass test	
		double tempBalance = balance;
		
		//set temp balance to new amount
		tempBalance = balance - howMuch;
		
		
					
					balance = balance - howMuch;
					
					System.out.println("your new balance is : �" + balance);
					
				}//end if
				
				else System.out.println("You cannnot enter a negative number!");
							
		
	}// end debit account method

}// end class
