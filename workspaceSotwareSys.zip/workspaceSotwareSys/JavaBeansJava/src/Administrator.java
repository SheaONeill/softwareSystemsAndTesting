/**
 * 
 */

/**
 * <pre>
 * 		&#64;author 	James O'Neill<br>
 *      Project 	JavaBeansJava
 * 		&#64;version 	1.0<br>
 * 		Date 		11 Mar 2016<br>
 *		UpDated 	11 Mar 2016<br>
 * </pre>
 */
public class Administrator {
	private String adminName;
	private String position;
	private String location;

	/**
	 * 
	 */
	public Administrator() {
		// TODO Auto-generated constructor stub
	}

	public void addUser() {
	}// end add user method

	public void deleteUser() {
	}// end delete user method

	public void createProduct() {
	}// end create product method

	public void deleteProduct() {
	}// end delete product method

	public void createCategory() {
	}// end create category method

	public void deleteCategory() {
	}// end delete category method

	public void updateStock() {
	}// end update stock

}// end class