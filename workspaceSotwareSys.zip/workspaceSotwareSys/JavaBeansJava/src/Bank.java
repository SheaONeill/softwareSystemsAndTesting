
public class Bank {
	
	private double inetrestRate = 8.5;
	private double transactionFee = 10;
	
	private Customer[] customers = new Customer[1000];
	

	public Bank() {
		// TODO Auto-generated constructor stub
	}
	
	public Customer[] getCustomer() {
		
		return customers;
		
	}//end get customer

}//end class
