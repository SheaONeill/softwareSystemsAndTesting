import java.util.Scanner;

public class TestingJavaBeanzApp {

	public static void main(String[] args) {

		// define variables
		int numberOfCustomers = 0;

		// create bank object
		Bank bank = new Bank();

		// get customer from getCustomer method in bank class
		Customer[] c = bank.getCustomer();

		// create scanner object for user input
		@SuppressWarnings("resource")
		Scanner getUserInput = new Scanner(System.in);

		while (true) {

			System.out.println("");
			System.out.println("Please enter Choice: ");
			System.out.println("1: Add Customer ");
			System.out.println("2: Deposit ");
			System.out.println("3: Debit Account ");
			System.out.println("4: Check Balance ");
			System.out.println("5: Exit ");
			int userChoice = getUserInput.nextInt();

			switch (userChoice) {
			// add customer
			case 1:
				System.out.println("In case " + userChoice + " Add Customer creating new account");

				System.out.println("Please enter initial amount here: ");
				double bal = getUserInput.nextDouble();

				// Discard the rest of the line
				// http://stackoverflow.com/questions/13993987/java-util-scanner-jumps-over-input-requests
				getUserInput.nextLine();

				System.out.println("amount entered: " + bal);

				System.out.println("Please enter account number here: ");
				String acc = getUserInput.nextLine();

				// create new account object and store new values for this
				// customer
				Account account = new Account(bal, acc);
				System.out.println("account number entered: " + acc);

				System.out.println("Please enter customerName here: ");
				String name = getUserInput.nextLine();
				System.out.println("customerName entered: " + name);

				// create new customer object and store new values
				Customer customer = new Customer(name, account);

				c[numberOfCustomers] = customer;

				System.out.println("Customer Name: " + name + " Balance: " + bal + " Customer Account Number: " + acc + " 2Has been added");
								
				// increment numberOfCustomers
				numberOfCustomers++;
				
				//testing testing
				System.out.println("Total Number of customers: " + numberOfCustomers);

				break;

			// deposit
			case 2:
				System.out.println("In case " + userChoice + " Deposit Funds");
				
				System.out.println("Total Number of customers: " + numberOfCustomers);
				
				//if no customers are found 
				if (numberOfCustomers == 0) {

					System.err.println(
							"Account number not found!" + "\nNumber Of Customers in Database: " + numberOfCustomers);

				} // end check numberOfCustomers

				else {
					
					//create bool and init at false
					boolean found = false;
					
					// Discard the rest of the line
					// http://stackoverflow.com/questions/13993987/java-util-scanner-jumps-over-input-requests
					getUserInput.nextLine();
					
					System.out.println("Please enter account number here: ");
					acc = getUserInput.nextLine();

					// loop through the customer array
					for (int count = 0; count < numberOfCustomers; count++) {

						Account temp = c[count].getAccount();

						String accTemp = temp.getAccountNumber();
						
						//check to see if account matches 
						if (accTemp.equals(acc)) {

						System.out.println("Account number found : " + accTemp);
						
						System.out.println("Please enter deposit amount here: ");
						double money = getUserInput.nextDouble();
						
						//deposit money into account 
						temp.deposit(money);
						
						//set found account to true 
						found = true;

						}//end if found
						
					} // end count
					
					//if account number is not found 
					if(!found) {
						
						System.err.println(
								"Account number not found!" + "\nNumber Of Customers in Database: " + numberOfCustomers);
						
					}//end found is false

				} // end else

				break;

			// debit
			case 3:
				System.out.println("In case " + userChoice + " In Withdraw from Account ");

				System.out.println("Total Number of customers: " + numberOfCustomers);
				
				System.out.println("Enter account number");
				
                //if no customers are found 
				if (numberOfCustomers == 0) {

					System.err.println(
							"Account number not found!" + "\nNumber Of Customers in Database: " + numberOfCustomers);

				} // end check numberOfCustomers
                
                else {
                	
                	//create bool and init at false
					boolean found = false;
					
					// Discard the rest of the line
					// http://stackoverflow.com/questions/13993987/java-util-scanner-jumps-over-input-requests
					getUserInput.nextLine();
                    
					System.out.println("Please enter account number here: ");
					acc = getUserInput.nextLine();

					// loop through the customer array
					for (int count = 0; count < numberOfCustomers; count++) {

						Account temp = c[count].getAccount();

						String accTemp = temp.getAccountNumber();
						
						//check to see if account matches 
						if (accTemp.equals(acc)) {

						System.out.println("Account number found : " + accTemp);
						
						System.out.println("Please enter withdrawal amount here: ");
						
						double money = getUserInput.nextDouble();
						
						//deposit money into account 
						temp.withdraw(money);
						
						//set found account to true 
						found = true;

						}//end if found
						
					} // end count
					
					//if account number is not found 
					if(!found) {
						
						System.err.println(
								"Account number not found!" + "\nNumber Of Customers in Database: " + numberOfCustomers);
						
					}//end found is false

				} // end else

				break;

			// balance
			case 4:
				
				System.out.println("In case " + userChoice + " In Account Balance");

				System.out.println("Total Number of customers: " + numberOfCustomers);
				
				System.out.println("Enter account number");
				
                //if no customers are found 
				if (numberOfCustomers == 0) {

					System.err.println(
							"Account number not found!" + "\nNumber Of Customers in Database: " + numberOfCustomers);

				} // end check numberOfCustomers
                
                else {
                	
                	//create bool and init at false
					boolean found = false;
					
					// Discard the rest of the line
					// http://stackoverflow.com/questions/13993987/java-util-scanner-jumps-over-input-requests
					getUserInput.nextLine();
                    
					System.out.println("Please enter account number here: ");
					acc = getUserInput.nextLine();

					// loop through the customer array
					for (int count = 0; count < numberOfCustomers; count++) {

						Account temp = c[count].getAccount();

						String accTemp = temp.getAccountNumber();
						
						//check to see if account matches 
						if (accTemp.equals(acc)) {

						System.out.println("Account number found : " + accTemp);
						
						System.out.println("Balance is: "+temp.getBalance());
						
						//set found account to true 
						found = true;

						}//end if found
						
					} // end count
					
					//if account number is not found 
					if(!found) {
						
						System.err.println(
								"Account number not found!" + "\nNumber Of Customers in Database: " + numberOfCustomers);
						
					}//end found is false

				} // end else

				break;
			// exit
			case 5:
				System.out.println("In exit ");
				System.err.println(userChoice + " entered");

				System.exit(0);
				break;

			default:

				System.out.println("In default");

				break;
			}

		} // end while

	}// end main

}// end class TestingJavaBeanzApp

// ******************************************************************

class Bank {

	// set variables keep them private
	private double interestRate = 8.5;
	private double transactionFees = 10;

	// define a private array fo customers (alternative vector for this)
	private Customer[] customers = new Customer[1000];

	// calculate interest for the customer
	public void calculateInterest(Customer customer) {

		// get account from method in customer class
		Account a = customer.getAccount();

		// get balance for this account from getBalance method in customer class
		double bal = a.getBalance();

		// set interestAmount to balance multiplied by interestRate
		double interestAmount = bal * interestRate / 100;

		// set totalBalance to balance and interestAmount
		double totalBalance = bal + interestAmount;

		System.out.println("Interest Amount = �" + interestAmount);
		System.out.println("Total Balance after adding Interest = �" + totalBalance);

	}// end calculate interest

	// interest rate
	public double getInterestRate() {

		// return this when called
		return interestRate;
	}// end get rate

	// transaction fee
	public double getTransactionFees() {

		// return this when called
		return transactionFees;

	}// end get transaction fees

	// customer array
	public Customer[] getCustomer() {

		// return this when called
		return customers;

	}// end get customer

}// end class bank

// ******************************************************************

class Account {

	// set private variables
	private Double balance = 100.00;
	private String accountNumber;
	private boolean firstTime = true;

	// create account constructor
	public Account(String acc) {

		// set accountID to acc
		accountNumber = acc;

	}// end constructor

	public Account(double bal, String acc) {

		// check to see if balance is greater than 100
		if (bal > 100) {

			balance = bal;

		} // end check

		else {

			// set the balance to 100
			balance = 100.00;

		} // end else

		// set accountID to acc
		accountNumber = acc;

	}// end constructor

	public void deposit(double howMuch) {

		// check to see if deposit is positive
		if (howMuch > 0) {

			balance = balance + howMuch;

			System.out.println("your new balance is : �" + balance);

		} // end if

		else
			System.out.println("You cannnot enter a negative number!");

	}// end deposit method

	public void withdraw(double howMuch) {

		// check to see if debit is positive
		if (howMuch > 0) {

			// if its a new customer
			if (firstTime) {

				// create temporary balance variable wont affect balance yet
				// until we pass test
				double tempBalance = balance;

				// set temp balance to new amount
				tempBalance = balance - howMuch;

				// check if balance is greater than 100
				if (tempBalance > 100) {

					// set the balance
					balance = balance - howMuch;
					System.out.println("your new balance is : �" + balance);

				} // end check tempBalance

				// otherwise display error
				else {

					System.out.println("Insufficent funds to withdraw �" + howMuch);
					System.out.println("Your balance is : �" + balance);

				} // end false

				// set to true if not firstTime customer
				firstTime = false;

			} // end check firsTime customer

			// if not a firstTime customer
			else {

				// create new bank object
				Bank bank = new Bank();

				// create temporary balance variable wont affect balance yet
				// until we pass test
				double tempBalance = balance;

				// set temp balance to new amount minus fees from bank class
				tempBalance = tempBalance - howMuch - bank.getTransactionFees();

				// check if balance is greater than 100
				if (tempBalance > 100) {

					// set the balance
					balance = balance - howMuch;
					System.out.println("your new balance is : �" + balance);

				} // end check tempBalance

				// otherwise display error
				else {

					System.out.println("Insufficent funds to withdraw �" + howMuch);
					System.out.println("Your balance is : �" + balance);

				} // end error

			} // end else not a firstTime customer

		} // end if

		// if how much is negative do this
		else
			System.out.println("You cannnot enter a negative number!");

	}// end withdraw method

	public Double getBalance() {

		// return account balance when called
		return balance;

	}// end get balance

	public String getAccountNumber() {

		// return account number when called
		return accountNumber;

	}// end get balance

}// end class account

// ******************************************************************

class Customer {

	// create private variable
	private String name;

	// reference private account object from account class
	private Account account;

	Customer(String n, Account a) {

		// set customerName to value passed
		name = n;

		// set account to value passed
		account = a;

	}// end constructor

	public void display() {

		// display name and then get account details from account class
		System.out.println("Name = : " + name + "account number = : " + account.getAccountNumber() + "Balance = :"
				+ account.getBalance());

	}// end display details

	public String getName() {

		// return this when called
		return name;

	}// end getName method

	public Account getAccount() {

		// return this when called
		return account;

	}// end getName method

}// end class customer