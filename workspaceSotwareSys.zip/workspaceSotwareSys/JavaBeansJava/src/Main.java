import javax.swing.JFrame;
import java.util.Scanner;

/**
 * 
 */

/**
 * <pre>
 * 		@author 	James O'Neill<br>
 *      Project 	JavaBeansJava
 * 		@version 	1.0<br>
 * 		Date 		11 Mar 2016<br>
 *		UpDated 	11 Mar 2016<br>
 * </pre>
 */
public class Main extends JFrame {
	
	int numberOfCustomers = 0;
	Bank bank = new Bank();
	Customer[] c = bank.getCustomer();
	
	public Main() {
		// TODO Auto-generated constructor stub
		super("Test");
		
		Scanner getUserInput = new Scanner(System.in);
	     		
						
		
		while(true) {
		
		System.out.println("Please enter Choice: ");
		System.out.println("1: Add Customer ");
		System.out.println("2: Deposit ");
		System.out.println("3: Debit Account ");
		System.out.println("4: Check Balance ");
		System.out.println("5: Exit ");
		int userChoice = getUserInput.nextInt();
		
		switch (userChoice) {
		//add customer
		case 1:
			System.out.println("In Add Customer ");
						
			System.out.println("Please enter initial amount here: ");
			double bal = getUserInput.nextDouble();
			System.out.println("amount entered: " + bal);
						
			System.out.println("Please enter accountID here: ");
			String acc = getUserInput.nextLine();
			//create new account object and store new values
			Account account = new Account(acc, bal);
			
			System.out.println("accountID entered: " + acc);
			
			
			
			System.out.println("Please enter customerName here: ");
			String name = getUserInput.nextLine();
			System.out.println("customerName entered: " + name);
						
			//create new customer object and store new values
			Customer customer = new Customer(name, account);
			
			c[numberOfCustomers] = customer;
			numberOfCustomers++;
			
			System.out.println("Number of customers: " + numberOfCustomers);
			
			//loop through the customer array
			for (int count = 0; count < numberOfCustomers; count ++) {
				
				System.out.println(c[count].getCustomerName() + " Name");
			
			}//end count
			
			break;
		
	    //deposit
		case 2:
			System.out.println("In Deposit ");
			System.err.println(userChoice + " entered");
			break;
		
		//debit
		case 3:
			System.out.println("In Debit Account ");
			System.err.println(userChoice + " entered");
			break;
		
		//balance
		case 4:
			System.err.println(userChoice + " entered");
			System.out.println("In Check Balance ");
			break;
			
			//exit
		case 5:
			System.out.println("In exit ");
			System.err.println(userChoice + " entered");
			
			System.exit(0);
			break;

		default:
			
			System.out.println("In default");
						
			break;
		}
		
		}//end while
		
		//test create account
		
		
		
		//Account account = new Account("C012345678", 1000);
		
		//System.err.println("Test : " + account.getBalance());
		
		/*
		JPanel panel = new JPanel();
		getContentPane().add(panel);
		setSize(500,500);
		setVisible(true);*/
		
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Main main = new Main();
				
	}//end main
	
	

}//end class
