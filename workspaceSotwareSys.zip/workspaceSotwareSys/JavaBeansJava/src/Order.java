import java.util.Date;

/**
 * 
 */

/**
 * <pre>
 * 		&#64;author 	James O'Neill<br>
 *      Project 	JavaBeansJava
 * 		&#64;version 	1.0<br>
 * 		Date 		11 Mar 2016<br>
 *		UpDated 	11 Mar 2016<br>
 * </pre>
 */
public class Order {
	private String customerName;
	private Date date;
	private String orderID;

	/**
	 * 
	 */
	public Order() {
		// TODO Auto-generated constructor stub
	}

	public void confirm() {
	}// end confirm method

	public void close() {
	}// end close method
}// end class
